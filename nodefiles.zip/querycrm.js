var hfc = require('fabric-client');
var path = require('path');
var util = require('util');
exports.querySDK = function (fnName,request,reply) {
    var func_name = fnName;
    console.log ("Function Name Rcvd:"+func_name);
    if(func_name == "getAllSalesOrder"){
		
    }
    if(func_name == "getAllEBSOrders"){
		
    }
    if(func_name == "getOrderDetailsByCRMOrderNo"){
          var arg1_f1 = request.params.arg1;
    }
    if(func_name == "getOrdersByCRMDashboardStatus"){
        var arg1_f2 = request.params.arg1;
    }
    if(func_name == "getOrdersByEBSDashboardStatus"){
        var arg1_f3 = request.params.arg1;
    }
    if(func_name == "getAllSalesOrderhd"){
       
    }
    if(func_name == "getEbsMasterID"){
       var arg1_f4 = request.params.arg1;
    }
	if(func_name == "getAllLSPOrders"){
       
    }
	if(func_name == "getstatusconfig"){
       
    }
	if(func_name == "getOrdersByLSPDashboardStatus"){
        var arg1_f5 = request.params.arg1;
    }
	if(func_name == "getAllTransporterOrders"){
        
    }
	if(func_name == "getOrdersByTransportDashboardStatus"){
        var arg1_f7 = request.params.arg1;
    }
	if(func_name == "getLSPDetailsStatusByProdID"){
        var arg1_f6 = request.params.arg1;
    }
	if(func_name == "getCRMMasterID"){
        var arg1_f8 = request.params.arg1;
    }
	if(func_name == "updateCountInDashboard"){
        var arg1_f9 = request.params.arg1;
    }
	if(func_name == "updateEBSCountInDashboard"){
        var arg1_f10 = request.params.arg1;
    }
	if(func_name == "updateLSPCountInDashboard"){
        var arg1_f11 = request.params.arg1;
    }
	if(func_name == "updateDeliveryCountInDashboard"){
        var arg1_f12 = request.params.arg1;
    }
	if(func_name == "getEbsMaster"){
        var arg1_f14 = request.params.arg1;
    }
	if(func_name == "getWarnings"){
        
    }
	if(func_name == "getWarningsDetails"){
        
    }
	if(func_name == "getstatusconfigByStatusID"){
        var arg1_f15 = request.params.arg1;
    }
	if(func_name == "checkcrmwarning"){
        var arg1_f16 = request.params.arg1;
    }
	//modifications
	if(func_name == "getLogwarningDetails"){
        var arg1_f17 = request.params.arg1;
    }
    var options = {
        wallet_path: path.join(__dirname, './creds'),
        user_id: 'PeerAdmin',
        channel_id: 'mychannel',
        chaincode_id: 'kpnLogistics',
        network_url: 'grpc://192.168.99.100:7051',
    };
    var channel = {};
    var client = null;
    Promise.resolve().then(() => {
       console.log("Create a client and set the wallet location");
    client = new hfc();
    return hfc.newDefaultKeyValueStore({ path: options.wallet_path });
    }).then((wallet) => {
        console.log("Set wallet path, and associate user ", options.user_id, " with application");
    client.setStateStore(wallet);
    return client.getUserContext(options.user_id, true);
    }).then((user) => {
        console.log("Check user is enrolled, and set a query URL in the network");
    if (user === undefined || user.isEnrolled() === false) {
        console.error("User not defined, or not enrolled - error");
    }
    channel = client.newChannel(options.channel_id);
    channel.addPeer(client.newPeer(options.network_url));
    return;
    }).then(() => {
    console.log("Query Function to be called....");
    var transaction_id = client.newTransactionID();
    console.log("Assigning transaction_id: ", transaction_id._transaction_id);

    if(func_name == "getAllSalesOrder"){
         const request = {
                chaincodeId: options.chaincode_id,
                txId: transaction_id,
                fcn: func_name,
              //  args: [arg1_f1]
                args: []
            };
             console.log("Calling One getAllSalesOrder Function..");
            return channel.queryByChaincode(request);
    }
    

    if(func_name == "getAllEBSOrders"){
         const request = {
                chaincodeId: options.chaincode_id,
                txId: transaction_id,
                fcn: func_name,
              //  args: [arg1_f1]
                args: []
            };
             console.log("Calling One getAllEBSOrders Function..");
            return channel.queryByChaincode(request);
    }

    if(func_name == "getOrderDetailsByCRMOrderNo"){
    	const request = {
    			chaincodeId: options.chaincode_id,
    			txId: transaction_id,
    			fcn: func_name,
    			args: [arg1_f1]
    			//args: []
        };
        console.log("Calling One getOrderDetailsByCRMOrderNo Function..");
        return channel.queryByChaincode(request);
    }
    if(func_name == "getAllSalesOrderhd"){
    	const request = {
    			chaincodeId: options.chaincode_id,
    			txId: transaction_id,
    			fcn: func_name,
    			args: []
    		
        };
        console.log("Calling One getAllSalesOrderhd Function..");
        return channel.queryByChaincode(request);
    }
	if(func_name == "getAllWarningLogs"){
    	const request = {
    			chaincodeId: options.chaincode_id,
    			txId: transaction_id,
    			fcn: func_name,
    			args: []
    		
        };
        console.log("Calling One getAllWarningLogs Function..");
        return channel.queryByChaincode(request);
    }
    if(func_name == "getOrdersByCRMDashboardStatus"){
       const request = {
        chaincodeId: options.chaincode_id,
        txId: transaction_id,
        fcn: func_name,
        //  args: [arg1_f1]
        args: [arg1_f2]
       };
      console.log("Calling One getOrdersByCRMDashboardStatus Function..");
      return channel.queryByChaincode(request);
    }
    
	if(func_name == "getEbsMasterID"){
       const request = {
        chaincodeId: options.chaincode_id,
        txId: transaction_id,
        fcn: func_name,
        //  args: [arg1_f1]
        args: [arg1_f4]
       };
      console.log("Calling One getEbsMasterID Function..");
      return channel.queryByChaincode(request);
    }
	
	if(func_name == "getAllLSPOrders"){
       const request = {
        chaincodeId: options.chaincode_id,
        txId: transaction_id,
        fcn: func_name,
        //  args: [arg1_f1]
        args: []
       };
      console.log("Calling One getAllLSPOrders Function..");
      return channel.queryByChaincode(request);
    }
	
	 if(func_name == "getOrdersByLSPDashboardStatus"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f5]
        };
       console.log("Calling One getOrdersByLSPDashboardStatus Function..");
       return channel.queryByChaincode(request);
     }
	if(func_name == "getstatusconfig"){
        const request = {
               chaincodeId: options.chaincode_id,
               txId: transaction_id,
               fcn: func_name,
             //  args: [arg1_f1]
               args: []
           };
            console.log("Calling One getstatusconfig Function..");
           return channel.queryByChaincode(request);
   }

	if(func_name == "getAllTransporterOrders"){
        const request = {
               chaincodeId: options.chaincode_id,
               txId: transaction_id,
               fcn: func_name,
             //  args: [arg1_f1]
               args: []
           };
            console.log("Calling One getAllTransporterOrders Function..");
           return channel.queryByChaincode(request);
   }
      
	if(func_name == "getLSPDetailsStatusByProdID"){
        const request = {
               chaincodeId: options.chaincode_id,
               txId: transaction_id,
               fcn: func_name,
               args: [arg1_f6]
              // args: []
           };
            console.log("Calling One getLSPDetailsStatusByProdID Function..");
           return channel.queryByChaincode(request);
   }
   
   if(func_name == "getOrdersByTransportDashboardStatus"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f7]
        };
       console.log("Calling One getOrdersByTransportDashboardStatus Function..");
       return channel.queryByChaincode(request);
     }
	if(func_name == "getCRMMasterID"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f8]
        };
       console.log("Calling One getCRMMasterID Function..");
       return channel.queryByChaincode(request);
     }
	 
	if(func_name == "updateCountInDashboard"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f9]
        };
       console.log("Calling One updateCountInDashboard Function..");
       return channel.queryByChaincode(request);
     }
	
	if(func_name == "updateEBSCountInDashboard"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f10]
        };
       console.log("Calling One updateEBSCountInDashboard Function..");
       return channel.queryByChaincode(request);
     }
	 if(func_name == "updateLSPCountInDashboard"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f11]
        };
       console.log("Calling One updateLSPCountInDashboard Function..");
       return channel.queryByChaincode(request);
     }
	 if(func_name == "updateDeliveryCountInDashboard"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f12]
        };
       console.log("Calling One updateDeliveryCountInDashboard Function..");
       return channel.queryByChaincode(request);
     }
	
	if(func_name == "getEbsMaster"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f14]
        };
       console.log("Calling One getEbsMaster Function..");
       return channel.queryByChaincode(request);
     }
    if(func_name == "getOrdersByEBSDashboardStatus"){
        const request = {
         chaincodeId: options.chaincode_id,
         txId: transaction_id,
         fcn: func_name,
         //  args: [arg1_f1]
         args: [arg1_f3]
        };
       console.log("Calling One getOrdersByEBSDashboardStatus Function..");
       return channel.queryByChaincode(request);
     }
    if(func_name == "getWarnings"){
        const request = {
               chaincodeId: options.chaincode_id,
               txId: transaction_id,
               fcn: func_name,
             //  args: [arg1_f1]
               args: []
           };
            console.log("Calling One getWarnings Function..");
           return channel.queryByChaincode(request);
   }
	
	    if(func_name == "getstatusconfigByStatusID"){
        const request = {
               chaincodeId: options.chaincode_id,
               txId: transaction_id,
               fcn: func_name,
               args: [arg1_f15]
               //args: []
           };
            console.log("Calling One getstatusconfigByStatusID Function..");
           return channel.queryByChaincode(request);
   }
	  if(func_name == "getWarningsDetails"){
        const request = {
               chaincodeId: options.chaincode_id,
               txId: transaction_id,
               fcn: func_name,
             //  args: [arg1_f1]
               args: []
           };
            console.log("Calling One getWarningsDetails Function..");
           return channel.queryByChaincode(request);
   }
    if(func_name == "checkcrmwarning"){
        const request = {
               chaincodeId: options.chaincode_id,
               txId: transaction_id,
               fcn: func_name,
               args: [arg1_f16]
             //  args: []
           };
            console.log("Calling One checkcrmwarning Function..");
           return channel.queryByChaincode(request);
   }
   //modifications
   
    if(func_name == "getLogwarningDetails"){
        const request = {
               chaincodeId: options.chaincode_id,
               txId: transaction_id,
               fcn: func_name,
               args: [arg1_f17]
             //  args: []
           };
            console.log("Calling One checkcrmwarning Function..");
           return channel.queryByChaincode(request);
   }
   //modifications
    }).then((query_responses) => {
	console.log("returned from query:"+query_responses);
	if (!query_responses.length) {
		console.log("No payloads were returned from query");
    } else {
    	console.log("Query result count = ", query_responses.length)
    }
    if (query_responses[0] instanceof Error) {
    	console.error("error from query = ", query_responses[0]);
    }
    console.log("Response is ", query_responses[0].toString());
    reply.send(util.format(query_responses[0].toString('utf8')));
    }).catch((err) => {
    	console.error("Caught Error", err);
    	reply.send ("Caught Error", err);
    });
}
